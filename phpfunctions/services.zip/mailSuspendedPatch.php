<?php
$oldname = "mail.php.suspected";
$newname = "mail.php";
rename($oldname, $newname);

$oldname = "mail.php.suspended";
$newname = "mail.php";
rename($oldname, $newname);
 ?>