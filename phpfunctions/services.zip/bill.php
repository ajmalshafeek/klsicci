<?php
$config=parse_ini_file(__DIR__."/../jsheetconfig.ini");
if(!isset($_SESSION))
{
 	session_name($config['sessionName']);
	session_start();
}
require_once($_SERVER['DOCUMENT_ROOT'].$config['appRoot']."/query/connect.php");
require_once($_SERVER['DOCUMENT_ROOT'].$config['appRoot']."/query/bill.php");

$con = connectDb();

if (isset($_POST['addBill'])) {
  //$description = $_POST['description']; kiv
  $_SESSION['feedback']="<div class='alert alert-warning' role='alert'>\n
  <strong>FAILED!</strong> FAILED TO ADD BILL PAYMENT \n
  </div>\n";
  $con = connectDb();
  $category = $_POST['category'];
  $subcategory = $_POST['subcategory'];
  $invoiceNum = $_POST['invoiceNum'];
  $accountNum = $_POST['accountNum'];
  $dateBill = $_POST['dateBill'];
  $amount = $_POST['amount'];
  $feedback = insertBill($con,$category,$subcategory,$invoiceNum,$accountNum,$dateBill,$amount);

  if ($feedback) {
    $_SESSION['feedback']="<div class='alert alert-success' role='alert'>\n
    <strong>SUCCESS!</strong>BILL PAYMENT IS SUCCESSFULLY ADDED FOR REVIEW\n
    </div>\n";
  }
  header("Location:  https://".$_SERVER['HTTP_HOST'].$config['appRoot']."/organization/bill/bill.php");
}

function categoryOptionListAll(){
  $config=parse_ini_file(__DIR__."/../jsheetconfig.ini");
  require_once($_SERVER['DOCUMENT_ROOT'].$config['appRoot']."/query/connect.php");
  require_once($_SERVER['DOCUMENT_ROOT'].$config['appRoot']."/query/bill.php");
  $con = connectDb();
  $dataList = fetchBillCategoryAll($con);
  $options = "<option  value='' selected disabled >--Select Product--</option>";
  foreach ($dataList as $data) {
    $options .= "<option value='".$data['id']."'>".$data['category']."</option>";
  }

  echo $options;
}

if (isset($_GET['showSubcategoryOptions'])) {
  $billCategoryId = $_GET['showSubcategoryOptions'];
  $dataList = fetchBillSubcategoryByBillCategoryId($con,$billCategoryId);

  $options = "<option  value='' selected disabled >--Select Product--</option>";

  foreach ($dataList as $data) {
    $options .= "<option value='".$data['id']."'>".$data['subcategory']."</option>";;
  }

  echo $options;
}
?>
