<?php
$config = parse_ini_file(__DIR__ . "/../jsheetconfig.ini");
date_default_timezone_set("Asia/Kuala_Lumpur");
if (!isset($_SESSION)) {
    session_name($config['sessionName']);
    session_start();
}
require_once($_SERVER['DOCUMENT_ROOT'] . $config['appRoot'] . "/query/connect.php");
require_once($_SERVER['DOCUMENT_ROOT'] . $config['appRoot'] . "/query/registration.php");

if (isset($_POST['regClientByForm'])) {
    ob_start();
    $name = $_POST['name'];
    $company = $_POST['company'];
    $email = $_POST['email'];
    $email1 = $_POST['email1'];
    $country = $_POST['country'];
    $status = 2;
    $emailstr = filter_var($email, FILTER_SANITIZE_EMAIL);
    $email1str = filter_var($email1, FILTER_SANITIZE_EMAIL);
    ob_clean();
    ob_end_clean();
    if ($email1str === $emailstr) {
        $con = connectDb();
        $bool = checkIfCompanyExist($con, $company);
        if ($bool) {
            $var = checkIfEmailExist($con, $email);
            if ($var) {
                $request = newStoreAccountRequest($con, $name, $company, $email, $country, $status);
                if ($request) {
                    $_SESSION['message'] = "<div class='alert alert-success' style='margin-right: auto;margin-right: auto'>Request send for new account you will recieve an email regarding activation account</div>";
                    header("Location:  https://" . $_SERVER['HTTP_HOST'] . $config['appRoot'] . "/client/index.php");
                } else {
                    $_SESSION['message'] = "<div class='alert alert-warning' style='margin-right: auto;margin-right: auto'>Request not send</div>";
                    header("Location:  https://" . $_SERVER['HTTP_HOST'] . $config['appRoot'] . "/client/index.php");
                }
            } else {
                $_SESSION['message'] = "<div class='alert alert-warning' style='margin-right: auto;margin-right: auto'>Email already exists</div>";
                header("Location:  https://" . $_SERVER['HTTP_HOST'] . $config['appRoot'] . "/client/index.php");
            }
        } else {
            $_SESSION['message'] = "<div class='alert alert-warning' style='margin-right: auto;margin-right: auto'>Company already exists</div>";
            header("Location:  https://" . $_SERVER['HTTP_HOST'] . $config['appRoot'] . "/client/index.php");
        }
    } else {
        $_SESSION['message'] = "<div class='alert alert-warning' style='margin-right: auto;margin-right: auto'>Email not match</div>";
        header("Location:  https://" . $_SERVER['HTTP_HOST'] . $config['appRoot'] . "/client/index.php");
    }

    header("Location:  https://" . $_SERVER['HTTP_HOST'] . $config['appRoot'] . "/client/index.php");
}
